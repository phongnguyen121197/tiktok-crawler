# File này để Python nhận diện thư mục app là một package
# Để trống hoặc thêm:

__version__ = "1.0.0"